# OPERATION AH-W — Autonomous Hardware-Workforce Operation

**System codename:** AH-W · **Target host:** Dell Latitude E7240 (8 GB DDR3L, Haswell dual-core, 0 VRAM, SSD)
**Core thesis:** decouple the local orchestration frontend from remote cloud inference — zero model weights, PyTorch, or CUDA on the host.

---

## ⚠️ Critical Security Finding (from the K2.7 review)

Two live NVIDIA NIM API keys (`nvapi-...`) were shipped inline in the briefing. **Both must be treated as compromised — revoke and rotate them at build.nvidia.com immediately.** No key is stored anywhere in this repository; the production daemon must read `$env:NVIDIA_API_KEY` only.

## K2.7 Architectural Verification — 5 Pillars

| # | Pillar | Verdict |
|---|--------|---------|
| P1 | Zero local weights — all inference offloaded to NIM REST endpoints | ✅ PASS — host holds no PyTorch/CUDA |
| P2 | SQLite blackboard — ACID ledger (`ahw_memory.db`) replaces RAM arrays | ✅ PASS — sound for 24/7 SSD-backed runs |
| P3 | Model multiplexing — inkling=CEO, 70B=coder, 8B=researcher across 3 isolated ~40 RPM buckets | ✅ PASS — prevents 429 collisions |
| P4 | 429 circuit-breaker — 1.5 s pause + fallback bucket reroute | ⚠️ WARN — works, but recommend exponential backoff + jitter to avoid thundering-herd |
| P5 | Credential hygiene | ❌ FAIL — hardcoded keys in briefing; rotate and env-var only |

## What This Repository Contains (currently implemented)

A **zero-dependency, static simulation of the AH-W Control Plane HUD** — the same dark sci-fi interface `ahw_demo.py` would serve at `http://localhost:8000`, running entirely client-side:

- **Mission directive input** with full pipeline execution (`EXECUTE PIPELINE`, Ctrl+Enter)
- **Inkling CEO phase**: streamed `reasoning_content` CoT trace at simulated 92.29 tok/s, followed by `dispatch_workforce_tasks()` JSON DAG emission
- **Parallel workforce dispatch** mirroring `asyncio.gather()`: `meta/llama-3.1-70b-instruct` (coder) and `meta/llama-3.1-8b-instruct` (researcher) run concurrently with live terminal output
- **429 circuit-breaker demo**: pipeline run #2 forces the coder bucket to 429 → 1.5 s pause → reroute to `nemotron-3-nano-30b`; run #3 forces the researcher onto `ministral-14b`
- **ACID transaction ledger** (`SEQ / AGENT / EVENT / MODEL / STATUS`) with row-flash animation on commit
- **SSE event stream panel** rendering `event: ledger_insert` payloads exactly as `/api/stream` would
- **Host telemetry gauges**: 85 MB daemon + 160 MB HUD = 245 MB ceiling (3.0 % of 8 192 MB), with zero-swap / zero-weights checks
- **Animated dispatch DAG** (SVG) lighting CEO → coder/researcher edges during execution
- **K2.7 verification strip** showing the five-pillar review verdicts in-page

## Entry Points (URIs)

| Path | Description |
|------|-------------|
| `/` or `/index.html` | The complete control plane HUD — the only page |
| `tables/ahw_ledger` | RESTful Table API endpoint the HUD POSTs ledger rows to (preview persistence) |

**Controls:** `EXECUTE PIPELINE` runs the simulation · `⟲ RESET` clears HUD state · run #2 → coder fallback, run #3 → researcher fallback.

## Data Model & Storage

**Table:** `ahw_ledger` (preview persistence via RESTful Table API; production target is SQLite `ahw_memory.db` on the E7240 SSD)

| Field | Type | Purpose |
|-------|------|---------|
| `id` | text | System UUID |
| `seq` | number | Monotonic transaction sequence |
| `agent` | text (enum) | SYSTEM / CEO_PLANNER / CODER / RESEARCHER |
| `event` | text | PIPELINE_INIT, TOOL_CALL, RATE_LIMIT_429, ACID COMMIT… |
| `model` | text | NIM model bucket (or `ahw_demo.py` / `ahw_memory.db`) |
| `status` | text | Outcome (`DAG OK`, `429 — RETRY`, `OK · 3.21s`…) |
| `ts` | text | Wall-clock `HH:MM:SS` |

## Not Yet Implemented (by design — outside static-site scope)

- The FastAPI/Uvicorn daemon, real `asyncio.gather` NIM calls, and live `/api/stream` SSE endpoint — these are server-side Python and belong in `ahw_demo.py` on the E7240, not in this frontend build
- Real LLM inference of any kind (no LLM API integration in this environment)
- OS-level RAM sampling (gauges show the briefing's design budgets, not live RSS)

## Recommended Next Steps

1. **Rotate both leaked `nvapi-` keys** before any further work.
2. Implement `ahw_demo.py` per the briefing (FastAPI + `openai` SDK + SQLite), keeping this HUD as its served `index.html` and wiring the SSE panel to the real `EventSource('/api/stream')`.
3. Harden the circuit-breaker: exponential backoff with jitter instead of a fixed 1.5 s pause.
4. Add per-bucket token metering so the CEO can preemptively rebalance before hitting 40 RPM.

## File Structure

```
index.html        — HUD markup (semantic sections, SVG DAG)
css/style.css     — dark sci-fi theme, grid layout, LEDs, gauges (zero deps)
js/main.js        — pipeline simulation engine (vanilla JS, no libraries)
README.md         — this document
```
