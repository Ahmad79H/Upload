/* ═══════════════════════════════════════════════════════════════
   OPERATION AH-W — Control Plane Simulation Engine
   Zero-dependency vanilla JS. Simulates the full pipeline that
   ahw_demo.py (FastAPI + NIM) would execute on the E7240 host:

     directive ─▶ call_inkling_ceo() [CoT + tool DAG]
               ─▶ asyncio.gather( Lead_Coder[70B], Researcher[8B] )
               ─▶ 429 circuit-breaker → fallback bucket
               ─▶ log_to_memory()  [ACID ledger]
               ─▶ /api/stream      [SSE feed]

   Ledger rows are also persisted to the RESTful Table API
   (table: ahw_ledger) as a stand-in for ahw_memory.db.
   NO API keys or model weights exist anywhere in this build.
   ═══════════════════════════════════════════════════════════════ */

'use strict';

/* ─────────────── DOM handles ─────────────── */
const $ = (sel) => document.querySelector(sel);

const els = {
  clock:        $('#sys-clock'),
  linkLed:      $('#link-led'),
  linkLabel:    $('#link-label'),
  directive:    $('#directive-input'),
  runBtn:       $('#run-btn'),
  resetBtn:     $('#reset-btn'),
  cot:          $('#cot-terminal'),
  cotTps:       $('#cot-tps'),
  dagWrap:      $('#dag-json-wrap'),
  dagJson:      $('#dag-json'),
  gatherTag:    $('#gather-tag'),
  termCoder:    $('#term-coder'),
  termResearch: $('#term-researcher'),
  titleCoder:   $('#term-title-coder'),
  titleResearch:$('#term-title-researcher'),
  sse:          $('#sse-feed'),
  ledgerBody:   $('#ledger-tbody'),
  ledgerCount:  $('#ledger-count'),
  gaugeDaemon:  $('#gauge-daemon'), valDaemon: $('#val-daemon'),
  gaugeHud:     $('#gauge-hud'),    valHud:    $('#val-hud'),
  gaugeTotal:   $('#gauge-total'),  valTotal:  $('#val-total'),
  valPct:       $('#val-pct'),
  nodes: {
    directive:  $('#node-directive'),
    ceo:        $('#node-ceo'),
    coder:      $('#node-coder'),
    researcher: $('#node-researcher'),
  },
  edges: {
    coder:      $('#edge-ceo-coder'),
    researcher: $('#edge-ceo-researcher'),
  },
  cards: {
    ceo:        $('#card-ceo'),
    coder:      $('#card-coder'),
    researcher: $('#card-researcher'),
  },
};

/* ─────────────── Constants (from the AH-W briefing) ─────────────── */
const HOST = { RAM_MB: 8192, CEILING_MB: 245, DAEMON_MB: 85, HUD_MB: 160 };
const NIM_ENDPOINT = 'https://integrate.api.nvidia.com/v1';
const LEDGER_TABLE = 'ahw_ledger';

const MODELS = {
  ceo:        { primary: 'thinkingmachines/inkling',      fallback: 'nemotron-super-49b',      ttft: 3.6 },
  coder:      { primary: 'meta/llama-3.1-70b-instruct',   fallback: 'nemotron-3-nano-30b',     ttft: 0.85 },
  researcher: { primary: 'meta/llama-3.1-8b-instruct',    fallback: 'ministral-14b',           ttft: 0.35 },
};

/* ─────────────── Runtime state ─────────────── */
let running = false;
let runCount = 0;      // runs 2 & 3 exercise the 429 circuit-breaker
let ledgerSeq = 0;

/* ─────────────── Utilities ─────────────── */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

function esc(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/* Typewriter: append text char-by-char into a terminal <pre>. */
async function typeInto(term, text, cls = '', msPerChar = 7) {
  const span = document.createElement('span');
  if (cls) span.className = cls;
  term.appendChild(span);
  for (const ch of text) {
    span.textContent += ch;
    term.scrollTop = term.scrollHeight;
    await sleep(msPerChar);
  }
  return span;
}

function appendLine(term, text, cls = '') {
  const span = document.createElement('span');
  if (cls) span.className = cls;
  span.innerHTML = text;
  term.appendChild(span);
  term.appendChild(document.createTextNode('\n'));
  term.scrollTop = term.scrollHeight;
}

function clearTerm(term) { term.innerHTML = ''; }

/* ─────────────── System clock ─────────────── */
setInterval(() => { els.clock.textContent = stamp(); }, 1000);
els.clock.textContent = stamp();

/* ─────────────── Link status ─────────────── */
function setLink(mode) {
  els.linkLed.className = 'led';
  if (mode === 'active') {
    els.linkLed.classList.add('led-cyan', 'pulse');
    els.linkLabel.textContent = 'LINK: PIPELINE ACTIVE';
  } else if (mode === 'done') {
    els.linkLed.classList.add('led-green');
    els.linkLabel.textContent = 'LINK: COMPLETE';
  } else {
    els.linkLed.classList.add('led-amber');
    els.linkLabel.textContent = 'LINK: STANDBY';
  }
}

/* ─────────────── Agent cards ─────────────── */
function setCard(agent, state, label) {
  const card = els.cards[agent];
  card.classList.remove('active', 'fallback', 'done');
  if (state !== 'idle') card.classList.add(state);
  const led = card.querySelector('[data-led]');
  led.className = 'led';
  if (state === 'active') led.classList.add('led-cyan', 'pulse');
  else if (state === 'fallback') led.classList.add('led-amber', 'pulse');
  else if (state === 'done') led.classList.add('led-green');
  else led.classList.add('led-idle');
  card.querySelector('[data-state]').textContent = label;
}

/* ─────────────── ACID ledger (+ Table API persistence) ─────────────── */
async function persistRow(row) {
  try {
    const res = await fetch(`tables/${LEDGER_TABLE}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(row),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
  } catch (_) { /* preview offline — HUD ledger remains authoritative */ }
}

function ledgerCommit(agent, event, model, status, stClass) {
  ledgerSeq += 1;
  const empty = els.ledgerBody.querySelector('.ledger-empty');
  if (empty) empty.remove();

  const tr = document.createElement('tr');
  tr.className = 'new-row';
  tr.innerHTML =
    `<td>${String(ledgerSeq).padStart(3, '0')}</td>` +
    `<td>${esc(agent)}</td>` +
    `<td>${esc(event)}</td>` +
    `<td>${esc(model)}</td>` +
    `<td class="${stClass}">${esc(status)}</td>`;
  els.ledgerBody.appendChild(tr);
  while (els.ledgerBody.rows.length > 9) els.ledgerBody.deleteRow(0);
  els.ledgerCount.textContent = `${ledgerSeq} rows`;

  /* SSE: stream the SQL insert exactly as /api/stream would emit it */
  const payload = { seq: ledgerSeq, ts: stamp(), agent, event, model, status };
  appendLine(els.sse, `<span class="dim">${stamp()}</span> <span class="ev">event:</span> ledger_insert`, 'sse-event');
  appendLine(els.sse, `<span class="ev">data:</span> ${esc(JSON.stringify(payload))}`, 'sse-event');

  persistRow({ seq: ledgerSeq, agent, event, model, status, ts: stamp() });
}

async function restoreLedger() {
  try {
    const res = await fetch(`tables/${LEDGER_TABLE}?limit=50`);
    if (!res.ok) return;
    const body = await res.json();
    const rows = (body.data || []).slice(-9);
    if (!rows.length) return;
    const empty = els.ledgerBody.querySelector('.ledger-empty');
    if (empty) empty.remove();
    let maxSeq = 0;
    for (const r of rows) {
      maxSeq = Math.max(maxSeq, Number(r.seq) || 0);
      const tr = document.createElement('tr');
      const stClass = /429|FAIL/i.test(r.status || '') ? 'st-warn' : 'st-ok';
      tr.innerHTML =
        `<td>${String(r.seq ?? '—').padStart(3, '0')}</td>` +
        `<td>${esc(r.agent ?? '')}</td>` +
        `<td>${esc(r.event ?? '')}</td>` +
        `<td>${esc(r.model ?? '')}</td>` +
        `<td class="${stClass}">${esc(r.status ?? '')}</td>`;
      els.ledgerBody.appendChild(tr);
    }
    ledgerSeq = maxSeq;
    els.ledgerCount.textContent = `${ledgerSeq} rows (restored)`;
    appendLine(els.sse, `<span class="dim">// restored ${rows.length} prior ACID transaction(s) from table store</span>`);
  } catch (_) { /* table store unavailable in this context */ }
}

/* ─────────────── Telemetry gauges ─────────────── */
function bootTelemetry() {
  const pct = ((HOST.CEILING_MB / HOST.RAM_MB) * 100).toFixed(1);
  els.valPct.textContent = pct;
  // staggered ramp for a cold-boot feel
  setTimeout(() => {
    els.gaugeDaemon.style.width = '100%';           // 85/85 budget
    els.valDaemon.textContent = HOST.DAEMON_MB;
  }, 400);
  setTimeout(() => {
    els.gaugeHud.style.width = '100%';              // 160/160 budget
    els.valHud.textContent = HOST.HUD_MB;
  }, 800);
  setTimeout(() => {
    els.gaugeTotal.style.width = '100%';            // exactly at 245 MB ceiling
    els.valTotal.textContent = HOST.CEILING_MB;
  }, 1200);
}

/* ─────────────── Phase 1: Inkling CEO (CoT + tool DAG) ─────────────── */
async function runCEO(directive) {
  setCard('ceo', 'active', 'REASONING… (CoT)');
  els.nodes.directive.classList.add('lit');
  els.nodes.ceo.classList.add('lit');
  els.cotTps.textContent = 'reasoning_content ▶ streaming';

  const short = directive.length > 64 ? directive.slice(0, 64) + '…' : directive;
  clearTerm(els.cot);
  await typeInto(els.cot, '[reasoning_content ▶]\n', 't-violet', 10);
  await typeInto(els.cot, `├─ parsing directive: "${short}"\n`, '', 6);
  await typeInto(els.cot, '├─ decomposing into dependency-ordered work units…\n', '', 6);
  await typeInto(els.cot, '├─ feasibility: fibonacci trade monitor → streaming compute → LEAD_CODER\n', '', 5);
  await typeInto(els.cot, '├─ feasibility: O(N) complexity audit → synthesis → RESEARCH_ANALYST\n', '', 5);
  await typeInto(els.cot, '├─ rate-limit isolation: coder→70B bucket, researcher→8B bucket (no 429 collision w/ CEO)\n', '', 4);
  await typeInto(els.cot, '└─ ✓ REASONING COMPLETE — 331 reasoning tokens @ 92.29 tok/s\n', 't-green', 9);

  const dag = {
    tool: 'dispatch_workforce_tasks',
    arguments: {
      coding_task: 'Implement a Python Fibonacci retracement monitor streaming trade signals; iterative generator, O(1) aux space.',
      research_task: 'Audit algorithmic complexity: prove iterative Θ(N)/Θ(1), reject naive Θ(2^N) recursion, assess memoized DP trade-offs.',
    },
    dag: { nodes: ['CEO_PLANNER', 'LEAD_CODER', 'RESEARCH_ANALYST'], edges: [['CEO_PLANNER', 'LEAD_CODER'], ['CEO_PLANNER', 'RESEARCH_ANALYST']] },
  };

  els.dagWrap.classList.remove('hidden');
  clearTerm(els.dagJson);
  await typeInto(els.dagJson, JSON.stringify(dag, null, 2) + '\n', '', 1);

  ledgerCommit('CEO_PLANNER', 'CoT_TRACE_EMITTED', MODELS.ceo.primary, '331 REASON TOK', 'st-info');
  ledgerCommit('CEO_PLANNER', 'TOOL_CALL dispatch_workforce_tasks', MODELS.ceo.primary, 'DAG OK', 'st-ok');

  els.cotTps.textContent = '✓ reasoning complete · 92.29 tok/s';
  setCard('ceo', 'done', 'DAG EMITTED — 92.29 TOK/S');
  els.nodes.ceo.classList.remove('lit');
  els.nodes.ceo.classList.add('done');
  els.edges.coder.classList.add('lit');
  els.edges.researcher.classList.add('lit');
}

/* ─────────────── Phase 2: parallel workforce (asyncio.gather) ─────────────── */
async function runAgent(agent, term, titleEl, outputLines, force429) {
  const spec = MODELS[agent];
  const t0 = performance.now();
  setCard(agent, 'active', `DISPATCHED → ${spec.primary}`);
  titleEl.className = 'term-title active';
  els.nodes[agent].classList.add('lit');
  clearTerm(term);

  await typeInto(term, `→ POST ${NIM_ENDPOINT}/chat/completions\n`, 'dim', 2);
  await typeInto(term, `  model=${spec.primary} · tool_choice=auto\n`, '', 2);
  await sleep(spec.ttft * 500); // scaled TTFT for watchability

  let usedModel = spec.primary;
  if (force429) {
    await typeInto(term, '← HTTP 429 TOO MANY REQUESTS — bucket cap ~40 RPM saturated\n', 't-red', 3);
    ledgerCommit(agent.toUpperCase(), 'RATE_LIMIT_429', spec.primary, '429 — RETRY', 'st-warn');
    await typeInto(term, '  circuit-breaker: pause 1.5s → reroute fallback bucket\n', 't-amber', 3);
    setCard(agent, 'fallback', `429 → FALLBACK ${spec.fallback}`);
    titleEl.className = 'term-title fallback';
    await sleep(1500); // the briefing's exact backoff constant
    await typeInto(term, `→ POST ${NIM_ENDPOINT}/chat/completions\n`, 'dim', 2);
    await typeInto(term, `  model=${spec.fallback}\n`, 't-amber', 2);
    usedModel = spec.fallback;
    await sleep(600);
  }

  await typeInto(term, `← 200 OK · TTFT ${spec.ttft}s · zero queue\n\n`, 't-green', 3);
  for (const line of outputLines) {
    await typeInto(term, line + '\n', line.startsWith('✓') ? 't-green' : '', 3);
  }

  const wall = ((performance.now() - t0) / 1000).toFixed(2);
  ledgerCommit(agent.toUpperCase(), force429 ? 'FALLBACK_COMMIT' : 'OUTPUT_COMMIT', usedModel, `OK · ${wall}s`, 'st-ok');
  setCard(agent, 'done', `COMMITTED · ${wall}s${force429 ? ' (VIA FALLBACK)' : ''}`);
  titleEl.className = 'term-title done';
  els.nodes[agent].classList.remove('lit');
  els.nodes[agent].classList.add('done');
}

const CODER_OUT = [
  '[code emitted — 214 tokens]',
  'def fib_monitor(prices, window=14):',
  '    fibs = fib_seq(window)          # Θ(window) once',
  '    for p in stream(prices):        # Θ(N) single pass',
  '        ratio = retrace(p, fibs)    # Θ(1) per tick',
  '        yield Signal(ratio, p)      # lazy, O(1) aux',
];

const RESEARCHER_OUT = [
  '[synthesis — 158 tokens]',
  'iterative fib(): Θ(N) time · Θ(1) space  ✓ optimal',
  'naive recursion: Θ(2^N) — REJECTED for live ticks',
  'binet closed-form: Θ(1) but float drift > n=70',
  'memoized DP: Θ(N)/Θ(N) — acceptable, not minimal',
  'verdict: iterative generator meets trading SLA',
];

/* ─────────────── Full pipeline orchestration ─────────────── */
async function runPipeline() {
  if (running) return;
  running = true;
  runCount += 1;
  els.runBtn.disabled = true;
  setLink('active');

  const directive = els.directive.value.trim() || 'unspecified directive';

  // reset transient DAG state (ledger persists — ACID semantics)
  for (const n of Object.values(els.nodes)) n.classList.remove('lit', 'done');
  for (const e of Object.values(els.edges)) e.classList.remove('lit');
  els.dagWrap.classList.add('hidden');
  els.gatherTag.textContent = 'asyncio.gather: 0/2';
  clearTerm(els.sse);
  appendLine(els.sse, `<span class="dim">// EventSource re-armed · run #${runCount} · ${stamp()}</span>`);

  ledgerCommit('SYSTEM', `PIPELINE_INIT run#${runCount}`, 'ahw_demo.py', 'BEGIN', 'st-info');

  /* Phase 1 — CEO */
  await runCEO(directive);

  /* Phase 2 — asyncio.gather: coder 429 on run #2, researcher 429 on run #3 */
  const coder429 = runCount === 2;
  const researcher429 = runCount === 3;

  let doneCount = 0;
  const bump = () => { doneCount += 1; els.gatherTag.textContent = `asyncio.gather: ${doneCount}/2`; };

  await Promise.all([
    runAgent('coder', els.termCoder, els.titleCoder, CODER_OUT, coder429).then(bump),
    runAgent('researcher', els.termResearch, els.titleResearch, RESEARCHER_OUT, researcher429).then(bump),
  ]);

  /* Phase 3 — commit + settle */
  els.edges.coder.classList.remove('lit');
  els.edges.researcher.classList.remove('lit');
  ledgerCommit('SYSTEM', 'PIPELINE_COMPLETE', 'ahw_memory.db', 'ACID COMMIT', 'st-ok');
  setLink('done');
  els.runBtn.disabled = false;
  running = false;
  setTimeout(() => { if (!running) setLink('idle'); }, 4000);
}

/* ─────────────── Reset ─────────────── */
function resetHUD() {
  if (running) return;
  ledgerSeq = 0;
  runCount = 0;
  els.ledgerBody.innerHTML = '<tr class="ledger-empty"><td colspan="5">// ledger empty — run pipeline to commit transactions</td></tr>';
  els.ledgerCount.textContent = '0 rows';
  clearTerm(els.cot);
  els.cot.innerHTML = '<span class="dim">// Awaiting directive. Inkling CoT trace will render here at ~92.29 tok/s.</span>\n';
  clearTerm(els.termCoder);
  clearTerm(els.termResearch);
  clearTerm(els.sse);
  els.sse.innerHTML = '<span class="dim">// EventSource idle. Live SQL ledger inserts stream here.</span>\n';
  els.dagWrap.classList.add('hidden');
  els.gatherTag.textContent = 'asyncio.gather: 0/2';
  els.cotTps.textContent = 'reasoning_content';
  els.titleCoder.className = 'term-title';
  els.titleResearch.className = 'term-title';
  for (const n of Object.values(els.nodes)) n.classList.remove('lit', 'done');
  for (const e of Object.values(els.edges)) e.classList.remove('lit');
  for (const a of ['ceo', 'coder', 'researcher']) setCard(a, 'idle', 'IDLE');
  setLink('idle');
}

/* ─────────────── Wire-up ─────────────── */
els.runBtn.addEventListener('click', runPipeline);
els.resetBtn.addEventListener('click', resetHUD);
els.directive.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') runPipeline();
});

bootTelemetry();
restoreLedger();
